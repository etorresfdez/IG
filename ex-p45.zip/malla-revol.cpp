// Nombre: Elena, Apellidos: Torres Fernández, Titulación: GIM
// email: eletofer26@correo.ugr.es, DNI: 77169308F
// *********************************************************************
// **
// ** Asignatura: INFORMÁTICA GRÁFICA
// ** 
// ** Mallas indexadas (implementación)
// ** Copyright (C) 2016-2023 Carlos Ureña
// **
// ** Implementación de las clases 
// **    + MallaRevol: malla indexada de triángulos obtenida por 
// **      revolución de un perfil (derivada de MallaInd)
// **    + MallaRevolPLY: malla indexada de triángulos, obtenida 
// **      por revolución de un perfil leído de un PLY (derivada de MallaRevol)
// **    + algunas clases derivadas de MallaRevol
// **
// ** This program is free software: you can redistribute it and/or modify
// ** it under the terms of the GNU General Public License as published by
// ** the Free Software Foundation, either version 3 of the License, or
// ** (at your option) any later version.
// **
// ** This program is distributed in the hope that it will be useful,
// ** but WITHOUT ANY WARRANTY; without even the implied warranty of
// ** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// ** GNU General Public License for more details.
// **
// ** You should have received a copy of the GNU General Public License
// ** along with this program.  If not, see <http://www.gnu.org/licenses/>.
// **
// *********************************************************************

#include "ig-aux.h"
#include "lector-ply.h"
#include "malla-revol.h"

using namespace std ;

// *****************************************************************************
// Método que crea las tablas de vértices, triángulos, normales y cc.de.tt.
// a partir de un perfil y el núm de copias que queremos de dicho perfil.
void MallaRevol::inicializar
(
   const std::vector<glm::vec3> & perfil,   // tabla de vértices del perfil
   const unsigned               num_copias  // número de copias del perfil
)
{
   using namespace glm ;
   unsigned nver = perfil.size();

   // cálculos previos para tabla de normales y texturas
   vector<glm::vec3> nor_perfil(nver);
   vector<glm::vec3> nor_arista(nver-1);
   vector<float> distancias(nver-1);
   vector<float> dist_0(nver);
   float suma_distancias = 0.0;
   float suma_parcial = 0.0;
   glm::vec3 arista = {0.0, 0.0, 0.0};

   // calculamos las normales de las aristas del perfil (normalizadas)
   // y las distancias entre cada vértice, tb calculamos la suma total de las distancias
   for (unsigned i=0; i<nver-1; i++)
   {
      arista = perfil[i+1] - perfil[i];
      nor_arista[i] = vec3( arista.y, -arista.x, 0.0 );
      
      if ( nor_arista[i].x != 0 || nor_arista[i].y != 0 || nor_arista[i].z != 0 )
         nor_arista[i] = normalize(nor_arista[i]);

      distancias[i] = length(arista);
      suma_distancias += distancias[i];
   }

   // calculamos las normales de los vértices del perfil (normalizadas)
   // y las distancias entre el vértice 0 y el resto de vértices del perfil
   nor_perfil[0] = nor_arista[0];
   dist_0[0] = 0.0;

   for (unsigned j=1; j<nver-1; j++)
   {
      nor_perfil[j] = nor_arista[j-1] + nor_arista[j];

      if ( nor_perfil[j].x != 0 || nor_perfil[j].y != 0 || nor_perfil[j].z != 0 )
         nor_perfil[j] = normalize(nor_perfil[j]);

      suma_parcial += distancias[j-1];
      dist_0[j] = suma_parcial / (1.0*suma_distancias);
   }

   nor_perfil[nver-1] = nor_arista[nver-2];


   // tabla de vértices, normales y coordenadas de textura
   if ( vertices.size() == 0 )
   {
      // añadimos los datos del perfil original
      for (unsigned v=0; v<nver; v++)
      {
         vertices.push_back(perfil[v]);
         nor_ver.push_back(nor_perfil[v]);
         cc_tt_ver.push_back(glm::vec2(0.0, 1.0-dist_0[v]));
      }

      // añadimos los vértices de las instancias del perfil
      for (unsigned i=1; i<num_copias; i++ ) // por cada copia del perfil
      {
         float angulo = (2.0*M_PI*i)/(num_copias-1);

         for (unsigned j=0; j<nver; j++) // por cada vértice de la copia
         {
            glm::mat3 mat_rot = {{ cos(angulo), 0.0, -sin(angulo)},
                                 {         0.0, 1.0,          0.0},
                                 { sin(angulo), 0.0,  cos(angulo)}};

            // calculamos la posición, normal y textura de cada vértice j de la copia i
            vertices.push_back( mat_rot * perfil[j] );
            nor_ver.push_back( normalize( mat_rot * nor_perfil[j] ) );
            cc_tt_ver.push_back(glm::vec2(i/(num_copias-1.0), 1.0-dist_0[j]));
         }
      }

      // volvemos a añadir los vértices, las normales y las texturas del perfil original
      for (unsigned v=0; v<nver; v++)
      {
         vertices.push_back(perfil[v]);
         nor_ver.push_back(nor_perfil[v]);                    
         cc_tt_ver.push_back(glm::vec2(0.0, 1.0-dist_0[v])); 
      }
   }

   // tabla de triángulos
   if (triangulos.size() == 0 )
   {
      for (unsigned i=0; i<(num_copias-1); i++) // por cada copia (menos la última)
      {
         for (unsigned j=0; j<(nver-1); j++) // por cada vértice (menos el último)
         {
            int k = i*nver+j;
            triangulos.push_back({ k, k+nver,   k+nver+1 });
            triangulos.push_back({ k, k+nver+1, k+1      });
         }
      }
   }
}

// -----------------------------------------------------------------------------
// constructor, a partir de un archivo PLY

MallaRevolPLY::MallaRevolPLY
(
   const std::string & nombre_arch,
   const unsigned      nperfiles
)
{
   ponerNombre( std::string("malla por revolución del perfil en '"+ nombre_arch + "'" ));   
   std::vector<glm::vec3> perfil;
   LeerVerticesPLY( nombre_arch, perfil );
   inicializar( perfil, nperfiles );
}


// -----------------------------------------------------------------------------
// constructor clase Cilindro
Cilindro::Cilindro ( const int num_verts_per, const unsigned nperfiles )
{
   // creamos el perfil original
   std::vector<glm::vec3> perfil;

   for (int i=0; i<num_verts_per; i++)
   {
      perfil.push_back({ 1, i/(num_verts_per-1.0), 0 }); 
   }

   // llamamos a inicializar
   inicializar( perfil, nperfiles );
}

// constructor clase CilindroP
CilindroP::CilindroP ( const int num_verts_per, const unsigned nperfiles,
                       const float radio, const float altura )
{
   // creamos el perfil original
   std::vector<glm::vec3> perfil;

   for (int i=0; i<num_verts_per; i++)
   {
      perfil.push_back({ radio, (i*altura)/(num_verts_per-1.0), 0 }); 
   }

   // llamamos a inicializar
   inicializar( perfil, nperfiles );

   ponerColor( glm::vec3( 0.54, 0.58, 0.59 )); // gris
}


// -----------------------------------------------------------------------------
// constructor clase Cono
Cono::Cono ( const int num_verts_per, const unsigned nperfiles )
{
   // creamos el perfil original
   std::vector<glm::vec3> perfil;

   for (int i=0; i<(num_verts_per); i++)
   {
      perfil.push_back({ 1 - (i/(num_verts_per-1.0)), i/(num_verts_per-1.0), 0 });
      // v.x = 0 en el último punto del perfil
   }

   // llamamos a inicializar
   inicializar( perfil, nperfiles );
}


// -----------------------------------------------------------------------------
// constructor clase Esfera
Esfera::Esfera ( const int num_verts_per, const unsigned nperfiles )
{
   // creamos el perfil original
   std::vector<glm::vec3> perfil;

   float borde1 = 0.1;
   float angulo = (M_PI*borde1)/(num_verts_per-1);
   perfil.push_back({ cos(angulo - M_PI/2), sin(angulo - M_PI/2), 0 });

   for (int i=1; i<(num_verts_per-1); i++)
   {
      angulo = (M_PI*i)/(num_verts_per-1);
      perfil.push_back({ cos(angulo - M_PI/2), sin(angulo - M_PI/2), 0 });
   }

   float borde2 = num_verts_per-1.1;
   angulo = (M_PI*borde2)/(num_verts_per-1);
   perfil.push_back({ cos(angulo - M_PI/2), sin(angulo - M_PI/2), 0 });

   // llamamos a inicializar
   inicializar( perfil, nperfiles );
}

// -----------------------------------------------------------------------------
// constructor clase Semiesfera
Semiesfera::Semiesfera ( const int num_verts_per, const unsigned nperfiles )
{
   // creamos el perfil original
   std::vector<glm::vec3> perfil;

   float angulo = 0.0;

   for (int i=0; i<(num_verts_per); i++)
   {
      angulo = (M_PI/2.0)*i/(num_verts_per-1);
      perfil.push_back({ cos(angulo), sin(angulo), 0 });
   }

   float borde = num_verts_per-1.1;
   angulo = (M_PI/2.0)*borde/(num_verts_per-1);
   perfil.push_back({ cos(angulo), sin(angulo), 0 });

   // llamamos a inicializar
   inicializar( perfil, nperfiles );
}

// -----------------------------------------------------------------------------
// constructor clase Anillo
Anillo::Anillo ( const int num_verts_per, const unsigned nperfiles, const float r, const float R )
{
   // creamos el perfil original
   std::vector<glm::vec3> perfil;

   glm::vec3 centro = { R, 0.0, 0.0 };
   float radio = r;
   float paso = (2.0*M_PI) / num_verts_per;

   for (int i = 0; i<(num_verts_per+1); i++)
   {
      float angulo = paso * i;
      float vertice_x = centro.x + radio * cos(angulo);
      float vertice_y = centro.y + radio * sin(angulo);

      perfil.push_back({ vertice_x, vertice_y, 0 });
   }

   // llamamos a inicializar
   inicializar( perfil, nperfiles );

   // cambiamos las coordenadas de textura de generación automática por las específicas de 
   // la proyección de un plano [0,1]x[0,1] a un toro
   for (unsigned i=0; i<=nperfiles; i++)
   {
      for (int j=0; j<num_verts_per; j++)
      {
         cc_tt_ver[i*num_verts_per + j] = glm::vec2( float(j/nperfiles), float(i/(num_verts_per-1.0)));
      }
   }

   ponerColor( glm::vec3( 1.0, 0.0, 0.0 ) ); // rojo
}

