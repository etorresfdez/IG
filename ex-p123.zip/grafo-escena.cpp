// Nombre: Elena, Apellidos: Torres Fernández, Titulación: GIM
// email: eletofer26@correo.ugr.es, DNI: 77169308F
// *********************************************************************
// **
// ** Asignatura: INFORMÁTICA GRÁFICA
// ** 
// ** Gestión de grafos de escena (implementación)
// ** Copyright (C) 2016-2023 Carlos Ureña
// **
// ** Implementación de: 
// **     + Clase 'NodoGrafoEscena' (derivada de 'Objeto3D')
// **     + Clase 'EntradaNGE' (una entrada de un nodo del grafo de escena)
// **     + Tipo enumerado 'TipoEntNGE' (tipo de entradas del nodo del grafo de escena)
// **
// ** This program is free software: you can redistribute it and/or modify
// ** it under the terms of the GNU General Public License as published by
// ** the Free Software Foundation, either version 3 of the License, or
// ** (at your option) any later version.
// **
// ** This program is distributed in the hope that it will be useful,
// ** but WITHOUT ANY WARRANTY; without even the implied warranty of
// ** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// ** GNU General Public License for more details.
// **
// ** You should have received a copy of the GNU General Public License
// ** along with this program.  If not, see <http://www.gnu.org/licenses/>.
// **
// *********************************************************************

#include "ig-aux.h"  
#include "grafo-escena.h"
#include "aplicacion-ig.h"
#include "seleccion.h"   // para 'ColorDesdeIdent'



// *********************************************************************
// Entrada del nodo del Grafo de Escena

// ---------------------------------------------------------------------
// Constructor para entrada de tipo sub-objeto

EntradaNGE::EntradaNGE( Objeto3D * pObjeto )
{
   assert( pObjeto != nullptr );
   tipo   = TipoEntNGE::objeto ;
   objeto = pObjeto ;
}
// ---------------------------------------------------------------------
// Constructor para entrada de tipo "matriz de transformación"

EntradaNGE::EntradaNGE( const glm::mat4 & pMatriz )
{
   tipo    = TipoEntNGE::transformacion ;
   matriz  = new glm::mat4() ; // matriz en el heap, puntero propietario
   *matriz = pMatriz ;
}

// ---------------------------------------------------------------------
// Constructor para entrada de tipo "matriz de transformación"

EntradaNGE::EntradaNGE( Material * pMaterial )
{
   assert( pMaterial != nullptr );
   tipo     = TipoEntNGE::material ;
   material = pMaterial ;
}

// -----------------------------------------------------------------------------
// Destructor de una entrada

EntradaNGE::~EntradaNGE()
{
   /**  no funciona debido a que se hacen copias (duplicados) de punteros
   if ( tipo == TipoEntNGE::transformacion )
   {
      assert( matriz != NULL );
      delete matriz ;
      matriz = NULL ;
   }
   * **/
}

// *****************************************************************************
// Nodo del grafo de escena: contiene una lista de entradas
// *****************************************************************************

NodoGrafoEscena::NodoGrafoEscena()
{

}

// -----------------------------------------------------------------------------
// Visualiza usando OpenGL

void NodoGrafoEscena::visualizarGL(  )
{
   using namespace std ;
   assert( apl != nullptr );

   // comprobar que hay un cauce y una pila de materiales y recuperarlos.
   Cauce *          cauce           = apl->cauce ;           assert( cauce != nullptr );
   PilaMateriales * pila_materiales = apl->pila_materiales ; assert( pila_materiales != nullptr );

   // COMPLETAR: práctica 3: implementar la visualización del nodo   
   // comprobar color
   if (tieneColor())
   {
      cauce->pushColor();
      cauce->fijarColor(leerColor());
   }

   // guardar el modelview actual
   cauce->pushMM();

   // recorrer todas las entradas del array que hay en el nodo:
   for (unsigned int i= 0; i< entradas.size(); i++)
   {
      switch( entradas[i].tipo )
      {
         case TipoEntNGE::objeto :
            entradas[i].objeto->visualizarGL();    // visualizamos el objeto
            break;
         case TipoEntNGE::transformacion :
            cauce->compMM( *(entradas[i].matriz)); // componemos la matriz transformación
            break;
         default:
            break;
      }
   }

   // restaura modelview guardada
   cauce->popMM();

   // restaurar color
   if (tieneColor())
   {
      cauce->popColor();
   }

   // COMPLETAR: práctica 4: añadir gestión de los materiales cuando la iluminación está activada    
   //
   // Si 'apl->iluminacion' es 'true', se deben de gestionar los materiales:
   //
   //   1. al inicio, hacer 'push' de la pila de materiales (guarda material actual en la pila)
   //   2. si una entrada es de tipo material, activarlo usando a pila de materiales
   //   3. al finalizar, hacer 'pop' de la pila de materiales (restaura el material activo al inicio)

   // ......
}

// *****************************************************************************
// visualizar pura y simplemente la geometría, sin colores, normales, coord. text. etc...

void NodoGrafoEscena::visualizarGeomGL(  )
{
   using namespace std ;
   // comprobar que hay un cauce 
   assert( apl != nullptr );
   Cauce * cauce = apl->cauce; assert( cauce != nullptr );
  
   // COMPLETAR: práctica 3: implementar la visualización del nodo (ignorando colores)
   // guardar el modelview actual
   cauce->pushMM();

   // recorrer todas las entradas del array que hay en el nodo:
   for (unsigned int i= 0; i< entradas.size(); i++)
   {
      switch( entradas[i].tipo )
      {
         case TipoEntNGE::objeto :
            entradas[i].objeto->visualizarGL(); // visualizamos el objeto
            break;
         case TipoEntNGE::transformacion :
            cauce->compMM( *(entradas[i].matriz)); // componemos la matriz transformación
            break;
         default:
            break;
      }
   }

   // restaura modelview guardada
   cauce->popMM();
}

// -----------------------------------------------------------------------------
// Visualizar las normales de los objetos del nodo

void NodoGrafoEscena::visualizarNormalesGL(  )
{
   using namespace std ;

   // comprobar que hay un cauce 
   assert( apl != nullptr );
   Cauce * cauce = apl->cauce; assert( cauce != nullptr );
  

   // COMPLETAR: práctica 4: visualizar las normales del nodo del grafo de escena
   //
   // Este método hace un recorrido de las entradas del nodo, parecido a 'visualizarGL', teniendo 
   // en cuenta estos puntos:
   //
   // - usar push/pop de la matriz de modelado al inicio/fin (al igual que en visualizatGL)
   // - recorrer las entradas, llamando recursivamente a 'visualizarNormalesGL' en los nodos u objetos hijos
   // - ignorar el color o identificador del nodo (se supone que el color ya está prefijado antes de la llamada)
   // - ignorar las entradas de tipo material, y la gestión de materiales (se usa sin iluminación)

   // .......

}

// -----------------------------------------------------------------------------
// visualizar el objeto en 'modo seleccion', es decir, sin iluminación y con los colores 
// basados en los identificadores de los objetos
void NodoGrafoEscena::visualizarModoSeleccionGL()
{
   using namespace std ;
   assert( apl != nullptr );
   Cauce * cauce = apl->cauce ; assert( cauce != nullptr );

   // COMPLETAR: práctica 5: visualizar este nodo en modo selección.
   //
   // Se debe escribir código para dar estos pasos:
   // 
   // 2. Leer identificador (con 'leerIdentificador'), si el identificador no es -1 
   //      + Guardar una copia del color actual del cauce (con 'pushColor')
   //      + Fijar el color del cauce de acuerdo al identificador, (usar 'ColorDesdeIdent'). 
   // 3. Guardar una copia de la matriz de modelado (con 'pushMM')
   // 4. Recorrer la lista de nodos y procesar las entradas transformación o subobjeto:
   //      + Para las entradas subobjeto, invocar recursivamente a 'visualizarModoSeleccionGL'
   //      + Para las entradas transformación, componer la matriz (con 'compMM')
   // 5. Restaurar la matriz de modelado original (con 'popMM')   
   // 6. Si el identificador no es -1, restaurar el color previo del cauce (con 'popColor')
   //
   // ........


}

// -----------------------------------------------------------------------------
// Añadir una entrada (al final).
// genérica (de cualqiuer tipo de entrada)
// devuelve el índice de la entrada añadida

unsigned NodoGrafoEscena::agregar( const EntradaNGE & entrada )
{
   // COMPLETAR: práctica 3: agregar la entrada al nodo, devolver índice de la entrada agregada

   entradas.push_back(entrada);
   unsigned indice = entradas.size() - 1;

   return indice;
}
// -----------------------------------------------------------------------------
// construir una entrada y añadirla (al final)
// objeto (copia solo puntero)

unsigned NodoGrafoEscena::agregar( Objeto3D * pObjeto )
{
   return agregar( EntradaNGE( pObjeto ) );
}
// ---------------------------------------------------------------------
// construir una entrada y añadirla (al final)
// matriz (copia objeto)

unsigned NodoGrafoEscena::agregar( const glm::mat4 & pMatriz )
{
   return agregar( EntradaNGE( pMatriz ) );
}
// ---------------------------------------------------------------------
// material (copia solo puntero)
unsigned NodoGrafoEscena::agregar( Material * pMaterial )
{
   return agregar( EntradaNGE( pMaterial ) );
}

// devuelve el puntero a la matriz en la i-ésima entrada
glm::mat4 * NodoGrafoEscena::leerPtrMatriz( unsigned indice )
{
   // COMPLETAR: práctica 3: leer un puntero a una matriz en una entrada de un nodo
   glm::mat4 *punt_matriz = nullptr;

   assert( indice < entradas.size() );
   assert( entradas[indice].tipo == TipoEntNGE::transformacion );
   assert( entradas[indice].matriz != nullptr );

   punt_matriz = entradas[indice].matriz;

   return punt_matriz ;
}

// -----------------------------------------------------------------------------
// si 'centro_calculado' es 'false', recalcula el centro usando los centros
// de los hijos (el punto medio de la caja englobante de los centros de hijos)

void NodoGrafoEscena::calcularCentroOC()
{
   using namespace std ;
   using namespace glm ;

   // COMPLETAR: práctica 5: calcular y guardar el centro del nodo
   //    en coordenadas de objeto (hay que hacerlo recursivamente)
   //   (si el centro ya ha sido calculado, no volver a hacerlo)
   // ........

}
// -----------------------------------------------------------------------------
// método para buscar un objeto con un identificador y devolver un puntero al mismo

bool NodoGrafoEscena::buscarObjeto
(
   const int          ident_busc, // identificador a buscar
   const glm::mat4 &  mmodelado,  // matriz de modelado
   Objeto3D       **  objeto,     // (salida) puntero al puntero al objeto
   glm::vec3 &        centro_wc   // (salida) centro del objeto en coordenadas del mundo
)
{
   using namespace std ;
   using namespace glm ;
   
   assert( 0 < ident_busc );

   // COMPLETAR: práctica 5: buscar un sub-objeto con un identificador
   // Se deben de dar estos pasos:

   // 1. calcula el centro del objeto, (solo la primera vez)
   // ........


   // 2. si el identificador del nodo es el que se busca, ya está (terminar)
   // ........


   // 3. El nodo no es el buscado: buscar recursivamente en los hijos
   //    (si alguna llamada para un sub-árbol lo encuentra, terminar y devolver 'true')
   // ........


   // ni este nodo ni ningún hijo es el buscado: terminar
   return false ;
}


// **************************************************************************************
// Clase GrafoEstrellaX

GrafoEstrellaX::GrafoEstrellaX( unsigned n )
{
   // variables
   const float angulo1 = M_PI/n;
   const float angulo2 = 2*angulo1;
   const float angulo3 = 0.0;
   const float angulo4 = M_PI/2.0;
   const unsigned n_verts = 5;
   const unsigned n_perfil = 20;   
   
   // estrella escalada
   NodoGrafoEscena *estrella_esc = new NodoGrafoEscena();
   estrella_esc->agregar( glm::translate( glm::vec3(0.0, -1.3, -1.3) ) );
   estrella_esc->agregar( glm::scale( glm::vec3(1.0, 2.6, 2.6) ) );
   estrella_esc->agregar( new EstrellaX(n) );

   // cono escalado
   NodoGrafoEscena *cono_esc = new NodoGrafoEscena();
   cono_esc->agregar( glm::rotate( angulo4, glm::vec3(1.0, 0.0, 0.0) ) );
   cono_esc->agregar( glm::translate( glm::vec3(0.0, 1.3, 0.0) ) );
   cono_esc->agregar( glm::scale( glm::vec3(0.28, 0.15, 0.28) ) );
   cono_esc->agregar( new Cono(n_verts, n_perfil) );


   // rotación de todo el objeto respecto el eje x
   unsigned ind = agregar( glm::rotate( angulo3, glm::vec3(1.0, 0.0, 0.0) ) );

   // agregamos la estrella
   agregar( estrella_esc );

   // agregamos tantos conos como puntas
   for (unsigned i=0; i<n; i++)
   {
      agregar( glm::rotate( angulo2, glm::vec3(1.0, 0.0, 0.0) ) );
      agregar( cono_esc ); 
   }

   // puntero a la matriz de rotación  
   pm_rotacion_x = leerPtrMatriz( ind );
}

unsigned GrafoEstrellaX::leerNumParametros() const 
{
   return 1;
}

void GrafoEstrellaX::actualizarEstadoParametro( const unsigned iParam, const float t_sec )
{
   if (iParam < leerNumParametros() )
   {
      float v = 0.0 + (2*M_PI*2.5)*t_sec; // 2.5 vueltas por segundo
      *pm_rotacion_x = glm::rotate( v, glm::vec3(1.0, 0.0, 0.0) );
   }
}

// **************************************************************************************
// Clase GrafoCubos

GrafoCubos::GrafoCubos()
{
   // variables
   const unsigned int n = 7;
   const float angulo1 = M_PI/2.0;
   const float angulo2 = -M_PI/2.0;
   const float angulo3 = M_PI;
   const float angulo4 = 0.0;

   // instancia objeto rejillaZ
   NodoGrafoEscena *rejilla_esc = new NodoGrafoEscena;
   rejilla_esc-> agregar( glm::rotate( angulo2, glm::vec3(1.0, 0.0, 0.0) ) );
   rejilla_esc-> agregar( glm::translate( glm::vec3(-0.4, -0.4, 0.4) ) );
   rejilla_esc-> agregar( glm::scale( glm::vec3(0.8, 0.8, 1.0) ) );
   rejilla_esc-> agregar( new RejillaZ(n, n) );

   // instancia objeto cubo
   NodoGrafoEscena *cubo_esc = new NodoGrafoEscena;
   unsigned ind = cubo_esc-> agregar( glm::rotate( angulo4, glm::vec3(0.0, 0.475, 0.0)) );
   cubo_esc-> agregar( glm::translate( glm::vec3(0.0, 0.55, 0.0) ) );
   cubo_esc-> agregar( glm::scale( glm::vec3(0.1, 0.15, 0.1) ) );
   cubo_esc-> agregar( new Cubo() );

   agregar( rejilla_esc );
   agregar( cubo_esc );
   agregar( glm::rotate( angulo3, glm::vec3(0.0, 0.0, 1.0) ) );
   agregar( rejilla_esc );
   agregar( cubo_esc );
   agregar( glm::rotate( angulo1, glm::vec3(0.0, 0.0, 1.0) ) );

   for (unsigned i=0; i<4; i++)
   {
      agregar( glm::rotate( angulo1, glm::vec3(1.0, 0.0, 0.0) ) );
      agregar( rejilla_esc );
      agregar( cubo_esc );
   }

   // puntero a la matriz de rotación  
   pm_rotacion = cubo_esc->leerPtrMatriz( ind );
}

unsigned GrafoCubos::leerNumParametros() const 
{
   return 1;
}

void GrafoCubos::actualizarEstadoParametro( const unsigned iParam, const float t_sec )
{
   if (iParam < leerNumParametros() )
   {
      float v = 0.0 + (2*M_PI)*t_sec; // 1 vuelta por segundo
      *pm_rotacion = glm::rotate( v, glm::vec3(0.0, 0.475, 0.0) );
   }
}

// **************************************************************************************
// IMPLEMENTACIÓN CLASES PARA OBJETO JERÁRQUICO ANDROID

Capsula::Capsula()
{
   // variables
   const unsigned n_verts = 40;
   const unsigned n_perfil = 50;

   // semiesfera superior
   NodoGrafoEscena *semi_sup = new NodoGrafoEscena;
   semi_sup-> agregar( glm::translate( glm::vec3(0.0, 1.0, 0.0) ) );
   semi_sup-> agregar( new Semiesfera(n_verts, n_perfil) );

   // semiesfera inferior
   NodoGrafoEscena *semi_inf = new NodoGrafoEscena;
   semi_inf-> agregar( glm::scale( glm::vec3(1.0, -1.0, 1.0) ) );
   semi_inf-> agregar( new Semiesfera(n_verts, n_perfil) );

   agregar( semi_inf );
   agregar( semi_sup );
   agregar( new Cilindro(n_verts, n_perfil) );
}

Cabeza::Cabeza()
{
   // variables
   const unsigned n_verts = 40;
   const unsigned n_perfil = 50;
   const float angulo1 = -M_PI/6.0;
   const float n = 10;

   // instancia ojo dcho
   NodoGrafoEscena *ojo = new NodoGrafoEscena;
   ojo-> agregar( glm::translate( glm::vec3(0.5, 0.5, 0.8) ) );
   ojo-> agregar( glm::scale( glm::vec3(0.1, 0.1, 1.0) ) );
   ojo-> agregar( new CirculoPlano(n) );
   ojo-> ponerColor( glm::vec3(0.0, 0.0, 0.0) );

   // instancia antena dcha
   NodoGrafoEscena *antena = new NodoGrafoEscena;
   antena-> agregar( glm::translate( glm::vec3(0.5, 1.0, 0.0) ) );
   antena-> agregar( glm::rotate( angulo1, glm::vec3(0.0, 0.0, 1.0) ) );
   antena-> agregar( glm::scale( glm::vec3(0.05, 0.2, 0.05) ) );
   antena-> agregar( new Capsula() );

   agregar( glm::translate( glm::vec3(0.0, 1.6, 0.0) ) );
   agregar( new Semiesfera(n_verts, n_perfil) );
   agregar( ojo );
   agregar( antena );
   agregar( glm::scale( glm::vec3(-1.0, 1.0, 1.0) ) );
   agregar( ojo );
   agregar( antena );
}

Android::Android()
{
   // variables
   const unsigned n_verts = 40;
   const unsigned n_perfil = 50;
   const float angulo = 0.0;

   // cuerpo
   NodoGrafoEscena *cuerpo = new NodoGrafoEscena;
   cuerpo-> agregar( glm::scale( glm::vec3(1.0, 1.5, 1.0) ) );
   cuerpo-> agregar( new Cilindro(n_verts, n_perfil) );
   
   // brazo dcho
   NodoGrafoEscena *brazo = new NodoGrafoEscena;
   brazo-> agregar( glm::translate( glm::vec3(1.25, 0.6, 0.0) ) );
   brazo-> agregar( glm::scale( glm::vec3(0.2, 0.4, 0.2) ) );
   brazo-> agregar( new Capsula() );

   // pie dcho
   NodoGrafoEscena *pie = new NodoGrafoEscena;
   pie-> agregar( glm::translate( glm::vec3(0.5, -0.4, 0.0) ) );
   pie-> agregar( glm::scale( glm::vec3(0.2, 0.4, 0.2) ) );
   pie-> agregar( new Capsula() );

   // cabeza rotada
   NodoGrafoEscena *cabeza_rot = new NodoGrafoEscena;
   unsigned ind1 = cabeza_rot->agregar( glm::rotate( angulo, glm::vec3(0.0, 2.6, 0.0) ) );
   cabeza_rot-> agregar( new Cabeza() );

   agregar( cuerpo );
   agregar( cabeza_rot );
   agregar( pie );
   agregar( brazo );
   agregar( glm::scale( glm::vec3(-1.0, 1.0, 1.0) ) );
   agregar( pie );
   agregar( brazo );
   
   ponerColor( glm::vec3(0.64, 0.77, 0.02) );

   // puntero a la matriz de rotación
   pm_rot_cabeza = cabeza_rot->leerPtrMatriz( ind1 );
   /* faltan las dos rotaciones de los brazos (distintas) */
}

unsigned Android::leerNumParametros() const 
{
   return 1;
}

void Android::actualizarEstadoParametro( const unsigned iParam, const float t_sec )
{
   if (iParam < leerNumParametros() )
   {
      float v = 0.0 + M_PI*t_sec; // 1/2 vuelta por segundo
      *pm_rot_cabeza = glm::rotate( v, glm::vec3(0.0, 2.6, 0.0) ); 
   }
}

