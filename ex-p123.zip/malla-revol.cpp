// Nombre: Elena, Apellidos: Torres Fernández, Titulación: GIM
// email: eletofer26@correo.ugr.es, DNI: 77169308F
// *********************************************************************
// **
// ** Asignatura: INFORMÁTICA GRÁFICA
// ** 
// ** Mallas indexadas (implementación)
// ** Copyright (C) 2016-2023 Carlos Ureña
// **
// ** Implementación de las clases 
// **    + MallaRevol: malla indexada de triángulos obtenida por 
// **      revolución de un perfil (derivada de MallaInd)
// **    + MallaRevolPLY: malla indexada de triángulos, obtenida 
// **      por revolución de un perfil leído de un PLY (derivada de MallaRevol)
// **    + algunas clases derivadas de MallaRevol
// **
// ** This program is free software: you can redistribute it and/or modify
// ** it under the terms of the GNU General Public License as published by
// ** the Free Software Foundation, either version 3 of the License, or
// ** (at your option) any later version.
// **
// ** This program is distributed in the hope that it will be useful,
// ** but WITHOUT ANY WARRANTY; without even the implied warranty of
// ** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// ** GNU General Public License for more details.
// **
// ** You should have received a copy of the GNU General Public License
// ** along with this program.  If not, see <http://www.gnu.org/licenses/>.
// **
// *********************************************************************

#include "ig-aux.h"
#include "lector-ply.h"
#include "malla-revol.h"

using namespace std ;

// *****************************************************************************
// Método que crea las tablas de vértices, triángulos, normales y cc.de.tt.
// a partir de un perfil y el núm de copias que queremos de dicho perfil.
void MallaRevol::inicializar
(
   const std::vector<glm::vec3> & perfil,   // tabla de vértices del perfil
   const unsigned               num_copias  // número de copias del perfil
)
{
   using namespace glm ;
   int nver = perfil.size();

   // tabla de vértices
   if ( vertices.size() == 0 )
   {
      // añadimos los vértices del perfil original
      for (int v=0; v<nver; v++)
      {
         vertices.push_back(perfil[v]);
      }

      // añadimos los vértices de las instancias del perfil
      for (unsigned int i=1; i<num_copias; i++ ) // por cada copia del perfil
      {
         for (int j=0; j<nver; j++) // por cada vértice de la copia
         {
            glm::vec3 centro = { 0, vertices[j].y, 0 };
            float radio = vertices[j].x;
            float angulo = (2.0*M_PI*i)/(num_copias-1);

            float v_x = centro.x + radio*cos(angulo);
            float v_y = centro.y + radio*0;
            float v_z = centro.z + radio*sin(angulo);

            vertices.push_back(vec3(v_x, v_y, v_z));
         }
      }

      // volvemos a añadir los vértices del perfil original
      for (int v=0; v<nver; v++)
      {
         vertices.push_back(perfil[v]);
      }
   }

   // tabla de triángulos
   if (triangulos.size() == 0 )
   {
      for (unsigned int i=0; i<(num_copias-1); i++) // por cada copia (menos la última)
      {
         for (int j=0; j<(nver-1); j++) // por cada vértice (menos el último)
         {
            int k = i*nver+j;
            triangulos.push_back({ k, k+nver,   k+nver+1 });
            triangulos.push_back({ k, k+nver+1, k+1      });
         }
      }
   }
}

// -----------------------------------------------------------------------------
// constructor, a partir de un archivo PLY

MallaRevolPLY::MallaRevolPLY
(
   const std::string & nombre_arch,
   const unsigned      nperfiles
)
{
   ponerNombre( std::string("malla por revolución del perfil en '"+ nombre_arch + "'" ));   
   std::vector<glm::vec3> perfil;
   LeerVerticesPLY( nombre_arch, perfil );
   inicializar( perfil, nperfiles );
}


// -----------------------------------------------------------------------------
// constructor clase Cilindro
Cilindro::Cilindro ( const int num_verts_per, const unsigned nperfiles )
{
   // creamos el perfil original
   std::vector<glm::vec3> perfil;

   for (int i=0; i<num_verts_per; i++)
   {
      perfil.push_back({ 1, i/(num_verts_per-1.0), 0 }); 
   }

   // llamamos a inicializar
   inicializar( perfil, nperfiles );
}

// constructor clase CilindroP
CilindroP::CilindroP ( const int num_verts_per, const unsigned nperfiles,
                       const float radio, const float altura )
{
   // creamos el perfil original
   std::vector<glm::vec3> perfil;

   for (int i=0; i<num_verts_per; i++)
   {
      perfil.push_back({ radio, (i*altura)/(num_verts_per-1.0), 0 }); 
   }

   // llamamos a inicializar
   inicializar( perfil, nperfiles );

   ponerColor( glm::vec3( 0.54, 0.58, 0.59 )); // gris
}


// -----------------------------------------------------------------------------
// constructor clase Cono
Cono::Cono ( const int num_verts_per, const unsigned nperfiles )
{
   // creamos el perfil original
   std::vector<glm::vec3> perfil;

   for (int i=0; i<(num_verts_per); i++)
   {
      perfil.push_back({ 1 - (i/(num_verts_per-1.0)), i/(num_verts_per-1.0), 0 });
      // v.x = 0 en el último punto del perfil
   }

   // llamamos a inicializar
   inicializar( perfil, nperfiles );
}


// -----------------------------------------------------------------------------
// constructor clase Esfera
Esfera::Esfera ( const int num_verts_per, const unsigned nperfiles )
{
   // creamos el perfil original
   std::vector<glm::vec3> perfil;

   float borde1 = 0.1;
   float angulo = (M_PI*borde1)/(num_verts_per-1);
   perfil.push_back({ cos(angulo - M_PI/2), sin(angulo - M_PI/2), 0 });

   for (int i=1; i<(num_verts_per-1); i++)
   {
      angulo = (M_PI*i)/(num_verts_per-1);
      perfil.push_back({ cos(angulo - M_PI/2), sin(angulo - M_PI/2), 0 });
   }

   float borde2 = num_verts_per-1.1;
   angulo = (M_PI*borde2)/(num_verts_per-1);
   perfil.push_back({ cos(angulo - M_PI/2), sin(angulo - M_PI/2), 0 });

   // llamamos a inicializar
   inicializar( perfil, nperfiles );
}

// -----------------------------------------------------------------------------
// constructor clase Semiesfera
Semiesfera::Semiesfera ( const int num_verts_per, const unsigned nperfiles )
{
   // creamos el perfil original
   std::vector<glm::vec3> perfil;

   float angulo = 0.0;

   for (int i=0; i<(num_verts_per); i++)
   {
      angulo = (M_PI/2.0)*i/(num_verts_per-1);
      perfil.push_back({ cos(angulo), sin(angulo), 0 });
   }

   float borde = num_verts_per-1.1;
   angulo = (M_PI/2.0)*borde/(num_verts_per-1);
   perfil.push_back({ cos(angulo), sin(angulo), 0 });

   // llamamos a inicializar
   inicializar( perfil, nperfiles );
}

// -----------------------------------------------------------------------------
// constructor clase Anillo
Anillo::Anillo ( const int num_verts_per, const unsigned nperfiles, const float r, const float R )
{
   // creamos el perfil original
   std::vector<glm::vec3> perfil;

   glm::vec3 centro = { R, 0.0, 0.0 };
   float radio = r;
   float paso = (2.0*M_PI) / num_verts_per;

   for (int i = 0; i<(num_verts_per+1); i++)
   {
      float angulo = paso * i;
      float vertice_x = centro.x + radio * cos(angulo);
      float vertice_y = centro.y + radio * sin(angulo);

      perfil.push_back({ vertice_x, vertice_y, 0 });
   }

   // llamamos a inicializar
   inicializar( perfil, nperfiles );

   ponerColor( glm::vec3( 1.0, 0.0, 0.0 ) ); // rojo
}

