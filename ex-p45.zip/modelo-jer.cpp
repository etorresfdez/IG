// Nombre: Elena, Apellidos: Torres Fernández, Titulación: GIM
// email: eletofer26@correo.ugr.es, DNI: 77169308F
// ***********************************************************************
// **
// ** Asignatura: INFORMÁTICA GRÁFICA
// ** 
// ** Diseño e implementación de un grado de escena parametrizado original
// **
// ***********************************************************************

#include "modelo-jer.h"
#include "ig-aux.h"
#include "aplicacion-ig.h"

//********************************************************************************************
// EJEMPLO DIAPOSITIVAS: Fachada

Ventana::Ventana()
{
   agregar( new CuadradoPlano() );                       // Cuadrado
   agregar( glm::translate(glm::vec3(0.1, 0.1, 0.0) ));  // Tra[0.1, 0.1]
   agregar( glm::scale(glm::vec3(0.4, 0.8, 1.0) ));      // Esc[0.4, 0.8]
   agregar ( new Marcos() );                             // Marcos
}

MarcoIzq::MarcoIzq()
{
   agregar( new CuadradoPlano() );                       // Cuadrado
   agregar( glm::translate(glm::vec3(0.0, 1.0, 0.0) ));  // Tra[0, 1]
   agregar( glm::scale(glm::vec3(0.9, -0.8, 1.0) ));     // Esc[0.9, -0.8]
   agregar( new TrianguloPlano() );                      // Triángulo
}

Marcos::Marcos()
{
   MarcoIzq *marco_izq = new MarcoIzq();
   agregar ( glm::scale(glm::vec3(0.8, 1.0, 1.0) ));     // Esc[0.8, 0.1]
   agregar ( marco_izq );                                // Marco Izq
   agregar ( glm::translate(glm::vec3(2.4, 0.0, 0.0) )); // Tra[2.4, 0.0]
   agregar ( glm::scale(glm::vec3(-1.0, 1.0, 1.0) ));    // Esc[-1, 1]
   agregar ( marco_izq );                                // Marco Izq
}

Puerta::Puerta()
{
   HojaDer *hoja_der = new HojaDer();
   agregar( hoja_der );
   agregar( glm::translate(glm::vec3(1.0, 0.0, 0.0) ));
   agregar ( glm::scale(glm::vec3(-1.0, 1.0, 1.0) ));    
   agregar ( hoja_der );                                
}

HojaDer::HojaDer()
{
   Pomo *pomo = new Pomo();
   agregar( glm::translate(glm::vec3(0.5, 0.0, 0.0) ));
   agregar ( pomo );
   agregar ( glm::scale(glm::vec3(0.5, 1.0, 1.0) ));
   agregar ( new CuadradoPlano() );
}

Pomo::Pomo()
{
   agregar( glm::translate(glm::vec3(0.15, 0.5, 0.0)) );
   agregar ( glm::scale(glm::vec3(0.1, 0.1, 1.0)) );
   agregar ( new CirculoPlano(10) );
}

Fachada::Fachada()
{
   // crear nuevo nodo (puerta)
   NodoGrafoEscena *puerta = new NodoGrafoEscena();
   puerta->agregar( glm::translate(glm::vec3(0.56, 0.0, 0.0)) );
   puerta->agregar( glm::scale(glm::vec3(0.3, 0.43, 1.0)) );
   puerta->agregar( new Puerta() );

   // crear nuevo nodo (ventana)
   NodoGrafoEscena *ventana = new NodoGrafoEscena();
   ventana->agregar( glm::scale(glm::vec3(0.3, 0.3, 1.0)) );
   ventana->agregar( new Ventana() );

   agregar ( new CasaPlana() );
   agregar ( puerta );
   agregar( glm::translate(glm::vec3(0.13, 0.13, 0.0)) );
   agregar( ventana );
   agregar( glm::translate(glm::vec3(0.0, 0.43, 0.0)) );
   agregar ( ventana );
   agregar( glm::translate(glm::vec3(0.43, 0.0, 0.0)) );
   agregar ( ventana );
}

FachadaP::FachadaP( float h, float alpha )
{
   // crear nuevo nodo (casa param)
   NodoGrafoEscena *casa_ey = new NodoGrafoEscena();
   unsigned ind1 = casa_ey->agregar( glm::scale(glm::vec3(1.0, h/1.5, 1.0)) );
   casa_ey->agregar( new CasaPlana() );

   // crear nuevo nodo (puerta)
   NodoGrafoEscena *puerta = new NodoGrafoEscena();
   puerta->agregar( glm::translate(glm::vec3(0.56, 0.0, 0.0)) );
   puerta->agregar( glm::scale(glm::vec3(0.3, 0.43, 1.0)) );
   puerta->agregar( new Puerta() );

   // crear nuevo nodo (ventana)
   NodoGrafoEscena *ventana = new NodoGrafoEscena();
   ventana->agregar( glm::scale(glm::vec3(0.3, 0.3, 1.0)) );
   ventana->agregar( new Ventana() );

   unsigned ind2 = agregar( glm::rotate(alpha, glm::vec3(0.0, 0.0, 1.0)) );
   agregar( casa_ey );
   agregar( puerta );
   agregar( glm::translate(glm::vec3(0.13, 0.13, 0.0)) );
   agregar( ventana );
   agregar( glm::translate(glm::vec3(0.0, 0.43, 0.0)) );
   agregar( ventana );
   agregar( glm::translate(glm::vec3(0.43, 0.0, 0.0)) );
   agregar( ventana );

   // guardar los punteros a las matrices que dependen de los parámetros
   pm_escy_h = casa_ey->leerPtrMatriz( ind1 );
   pm_rot_alpha = leerPtrMatriz( ind2 );
}

void FachadaP::fijarH( const float h_nuevo )
{
   *pm_escy_h = glm::scale( glm::vec3(1.0, h_nuevo/1.5, 1.0) );
}

void FachadaP::fijarAlpha( const float alpha_nuevo )
{
   *pm_rot_alpha = glm::rotate( alpha_nuevo, glm::vec3(0.0, 0.0, 1.0) );
}


//********************************************************************************************
// EJERCICIO ORIGINAL: Canasta

PosteVer24::PosteVer24()
{
   agregar( glm::scale( glm::vec3(0.1, 1.2, 0.1) ) );
   agregar( glm::translate( glm::vec3(0.0, 1.0, 0.0) ) );
   agregar( new Cubo24() );
}

PosteHor24::PosteHor24()
{
   ponerNombre( "Poste Horizontal" );
   ponerIdentificador( 2 );

   const float angulo2 = -M_PI/2.0;
   agregar( glm::translate( glm::vec3(-0.1, 2.4, 0.0) ) );
   agregar( glm::rotate( angulo2, glm::vec3(0.0, 0.0, 1.0) ) );
   agregar( glm::translate( glm::vec3(-0.1, 0.0, 0.0) )) ;
   agregar( glm::scale( glm::vec3(0.1, 0.6, 0.1) ) );
   agregar( glm::translate( glm::vec3(0.0, 1.0, 0.0) ) );
   agregar( new Cubo24() );
}

PosteDia24::PosteDia24()
{
   ponerNombre( "Poste Diagonal" );
   ponerIdentificador( 3 );

   const float angulo1 = -(2.65*M_PI)/8.0;
   agregar( glm::translate( glm::vec3(0.045, 1.75, 0.0) ) );
   agregar( glm::rotate( angulo1, glm::vec3(0.0, 0.0, 1.0) ) );
   agregar( glm::translate( glm::vec3(-0.025, 0.0, 0.0) ) );
   agregar( glm::scale( glm::vec3(0.025, 0.635, 0.1) ) );
   agregar( glm::translate( glm::vec3(0.0, 1.0, 0.0) ) );
   agregar( new Cubo24() );
}

PosteVer::PosteVer()
{
   agregar( glm::scale( glm::vec3(0.2, 0.6, 0.2) ) );
   agregar( new MallaTorre(4) );
}

PosteHor::PosteHor()
{
   const float angulo2 = -M_PI/2.0;
   agregar( glm::translate( glm::vec3(-0.1, 2.4, 0.0) ) );
   agregar( glm::rotate( angulo2, glm::vec3(0.0, 0.0, 1.0) ) );
   agregar( glm::translate( glm::vec3(-0.1, 0.0, 0.0) )) ;
   agregar( glm::scale( glm::vec3(0.2, 0.6, 0.2) ) );
   agregar( new MallaTorre(2) );
}

PosteDia::PosteDia()
{
   const float angulo1 = -(2.65*M_PI)/8.0;
   agregar( glm::translate( glm::vec3(0.09, 1.8, 0.0) ) );
   agregar( glm::rotate( angulo1, glm::vec3(0.0, 0.0, 1.0) ) );
   agregar( glm::translate( glm::vec3(-0.025, 0.0, 0.0) ) );
   agregar( glm::scale( glm::vec3(0.05, 0.585, 0.2) ) );
   agregar( new MallaTorre(2) );
}

Postes::Postes()
{
   ponerColor( glm::vec3(0.0, 0.0, 1.0) );
   agregar( new PosteDia24() );
   agregar( new PosteHor24() );
   agregar( new PosteVer24() );
}

Cuadro::Cuadro()
{
   // nombre e identificadores del objeto
   ponerIdentificador( 4 );
   ponerNombre( "Cuadro" );

   // marco interior
   NodoGrafoEscena *marco_int = new NodoGrafoEscena();
   float grosor = 0.02;
   const float angulo = M_PI/2.0;
   marco_int->ponerNombre( "marco interior" );
   marco_int->ponerIdentificador( -1 );
   marco_int->agregar( glm::translate( glm::vec3(1.151, 2.1, 0.275) ) );
   marco_int->agregar( glm::rotate( angulo, glm::vec3(0.0, 1.0, 0.0) ) );
   marco_int->agregar( glm::scale( glm::vec3(0.55, 0.55, 1.0) ) );
   marco_int->agregar( new MarcoXY(grosor) );

   // marco exterior
   NodoGrafoEscena *marco_ext = new NodoGrafoEscena();
   marco_ext->ponerNombre( "marco exterior" );
   marco_ext->ponerIdentificador( 4 );
   marco_ext->agregar( glm::translate( glm::vec3(1.151, 2.0, 1.0) ) );
   marco_ext->agregar( glm::rotate( angulo, glm::vec3(0.0, 1.0, 0.0) ) );
   marco_ext->agregar( glm::scale( glm::vec3(2.0, 1.0, 1.0) ) );
   marco_ext->agregar( new MarcoXY(grosor) );

   agregar( marco_int );
   agregar( marco_ext);
   agregar( glm::translate( glm::vec3(1.125, 2.5, 1.0) ) );
   agregar( glm::rotate( angulo, glm::vec3(0.0, 1.0, 0.0) ) );
   agregar( glm::translate( glm::vec3(1.0, 0.0, 0.0) ) );
   agregar( glm::scale( glm::vec3(1.0, 0.5, 0.025) ) ); 
   agregar( new Cubo24() );  
}

Aro::Aro()
{
   const int num_vert_per = 10;
   const unsigned nperfiles = 30;
   const float r = 0.02;
   const float R = 0.3;
   const float altura = 0.35;

   agregar( glm::translate( glm::vec3(1.15 + r + R, 2.2, 0.0) ) );
   agregar( new Anillo(num_vert_per, nperfiles, r, R) );
   agregar( glm::translate( glm::vec3(0.0, -altura, 0.0) ) );
   agregar( new CilindroP(num_vert_per, nperfiles, r + R, altura) );   
}

// Objeto jerárquico original --> Canasta
//
Canasta::Canasta()
{
   agregar( new Aro() );
   agregar( new Cuadro() );
   agregar( new Postes() );
}

// Objeto jerárquico Canasta con animacinoes (p3), iluminación y texturas (p4)
// y modo selección de subobjetos del modelo (p5)
//
CanastaP::CanastaP( float paltura, float pradio, float palpha )
{
   // variables
   const int num_vert_per = 10;
   const unsigned nperfiles = 30;
   const float r = 0.02;
   const float R = 0.3;
   const float altura = 0.35;

   // identificadores
   int id_poste_ver = 1;
   int id_aro = 5;

   // materiales
   Material *mat_red = new Material( new Textura( "red.jpg" ), 0.5, 1.0, 0.0, 0.5 ); // tabla de coord de textura de malla-revol
   mat_red->ponerNombre( "red" );                                                    // material difuso

   Material *mat_oxido = new Material( new Textura( "oxido-rojo.jpg" ), 0.6, 0.0, 1.0, 20.0 ); // tabla de coord de textura editada
   mat_oxido->ponerNombre( "óxido" );                                                          // material pseudo-especular

   Material *mat_metal = new Material( new TexturaXY( "metal-azul.jpg" ), 0.8, 0.0, 1.0, 10.0 ); // GACT + material pseudo-especular
   mat_metal->ponerNombre( "metal" );                                                            

   // red con textura
   NodoGrafoEscena *red_tex = new NodoGrafoEscena();
   red_tex-> agregar( mat_red ); 
   red_tex-> agregar( new CilindroP(num_vert_per, nperfiles, r + R, altura) );   

   // anillo con textura
   NodoGrafoEscena *anillo_tex = new NodoGrafoEscena();
   anillo_tex-> agregar( mat_oxido ); 
   anillo_tex-> agregar( new Anillo(num_vert_per, nperfiles, r, R) );

   // aro con nuevo radio
   NodoGrafoEscena *aro_radio = new NodoGrafoEscena();
   aro_radio->ponerNombre( "Aro" );
   aro_radio->ponerIdentificador( id_aro );
   unsigned ind4 = aro_radio->agregar( glm::translate( glm::vec3(1.15 + (R+r)*pradio, 2.2, 0.0 ) ) );
   unsigned ind3 = aro_radio->agregar( glm::scale( glm::vec3(pradio, 1.0, pradio) ) );
   aro_radio->agregar( anillo_tex );
   aro_radio->agregar( glm::translate( glm::vec3(0.0, -altura, 0.0) ) );
   aro_radio->agregar( red_tex ); 

   // poste vertical
   NodoGrafoEscena *poste_ver = new NodoGrafoEscena();
   poste_ver-> ponerNombre( "Poste Vertical" );
   poste_ver-> ponerIdentificador( id_poste_ver );
   unsigned ind1 = poste_ver-> agregar( glm::scale( glm::vec3(1.0, paltura, 1.0) ) );     // escalado poste ver
   poste_ver-> agregar( mat_metal );
   poste_ver-> agregar( new PosteVer24() );

   unsigned ind6 = agregar( glm::rotate( palpha, glm::vec3(1.0, 0.0, 0.0) ) );            // rotamos todo
   agregar( poste_ver );                                                                
   unsigned ind2 = agregar( glm::translate( glm::vec3(0.0, 2.4*paltura -2.4, 0.0) ) );    // traslación vertical
   agregar( aro_radio );                             
   agregar( new Cuadro() );           
   agregar( mat_metal );              
   agregar( new PosteDia24() );       
   agregar( new PosteHor24() );        

   // guardamos los punteros a las matrices
   pm_alt_poste = poste_ver->leerPtrMatriz( ind1 );
   pm_alt_resto = leerPtrMatriz( ind2 );
   pm_esc_aro   = aro_radio->leerPtrMatriz( ind3 );
   pm_tra_aro   = aro_radio->leerPtrMatriz( ind4 );
   pm_alp_rot   = leerPtrMatriz( ind6 );
}

unsigned CanastaP::leerNumParametros() const 
{
   return 3;
}

void CanastaP::actualizarEstadoParametro( const unsigned iParam, const float t_sec )
{
      if (iParam < leerNumParametros() )
      {
         // declaración variables
         float vmin = 0;
         float vmax = 0;
         float v = 0;

         // constantes usadas en la construcción del anillo y el cilindro
         const float r = 0.02; 
         const float R = 0.3;

         switch(iParam)
         {
            case (0):     
               vmin = 1.0;       // altura poste
               vmax = 3.0;
               v = (vmin + vmax)/2.0 + ((vmax - vmin)/2.0)*sin(2*M_PI*t_sec);
               *pm_alt_poste = glm::scale( glm::vec3(1.0, v, 1.0) );
               *pm_alt_resto = glm::translate( glm::vec3(0.0, 2.4*v -2.4, 0.0) );
               break;
            
            case(1):             // escalado aro
               vmin = 0.5;
               vmax = 1.5;
               v = (vmin + vmax)/2.0 + ((vmax - vmin)/2.0)*sin(2*M_PI*t_sec/2); 
               *pm_esc_aro = glm::scale( glm::vec3(v, 1.0, v) );
               *pm_tra_aro = glm::translate( glm::vec3(1.15 + (R+r)*v, 2.2, 0.0 ) );
               break;

            case(2):             // rotación canasta
               vmin = -M_PI/4.0;
               vmax = +M_PI/4.0;
               v = (vmin + vmax)/2.0 + ((vmax - vmin)/2.0)*sin(2*M_PI*t_sec/4); 
               *pm_alp_rot = glm::rotate( v, glm::vec3(1.0, 0.0, 0.0) );
               break;
            
            default:
               break;
         }
      }
}


