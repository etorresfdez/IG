// Nombre: Elena, Apellidos: Torres Fernández, Titulación: GIM
// email: eletofer26@correo.ugr.es, DNI: 77169308F

#ifndef EXAMEN_EC_P45_HPP
#define EXAMEN_EC_P45_HPP

#include "malla-ind.h"
#include "grafo-escena.h"

class MallaP4 : public MallaInd
{
    public:
        MallaP4();
};

class NodoP4 : public NodoGrafoEscena
{
    public:
        NodoP4();
};

class NodoUrbaP5 : public NodoGrafoEscena
{
    public:
        NodoUrbaP5( int n );
        virtual bool cuandoClick( const glm::vec3 & centro_wc) ;

    protected:
        glm::mat4 *mat_rotacion = nullptr;
};



#endif