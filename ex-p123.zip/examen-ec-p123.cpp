// Nombre: Elena, Apellidos: Torres Fernández, Titulación: GIM
// email: eletofer26@correo.ugr.es, DNI: 77169308F

#include "examen-ec-p123.h"

// ****************************************************************************
// Clase 'P1MallaCubo'

P1MallaCubo::P1MallaCubo()
:  MallaInd( "cubo colores modificado" )
{
   vertices =
      {  { -1.0, -1.0, -1.0 }, // 0
         { -1.0, -1.0, +1.0 }, // 1
         { -1.0, +1.0, -1.0 }, // 2
         { -1.0, +1.0, +1.0 }, // 3
         { +1.0, -1.0, -1.0 }, // 4
         { +1.0, -1.0, +1.0 }, // 5
         { +1.0, +1.0, -1.0 }, // 6
         { +1.0, +1.0, +1.0 }, // 7
         {  0.0, +1.0,  0.0 }, // 8 (superior)
         {  0.0, -1.0,  0.0 }  // 9 (inferior)
      } ;

   triangulos =
      {  {0,1,3}, {0,3,2},
         {4,7,5}, {4,6,7},
         {0,9,1}, {0,9,4}, {4,9,5}, {5,9,1}, // cara inferior
         {2,3,8}, {2,8,6}, {6,8,7}, {7,8,3}, // cara superior
         {0,6,4}, {0,2,6},
         {1,5,7}, {1,7,3}
      } ;

   col_ver =
      {  { 0, 0, 0 }, // 0-negro
         { 0, 0, 1 }, // 1-azul oscuro
         { 0, 1, 0 }, // 2-verde
         { 0, 1, 1 }, // 3-azul claro
         { 1, 0, 0 }, // 4-rojo
         { 1, 0, 1 }, // 5-rosa
         { 1, 1, 0 }, // 6-amarillo
         { 1, 1, 1 }, // 7-blanco
         { 1, 0, 0 }, // 8-rojo
         { 0, 1, 1 }  // 9-azul claro
      } ;
}

// ****************************************************************************
// Clase 'P2Rejilla'
P2Rejilla::P2Rejilla(unsigned int m, unsigned int n)
:  MallaInd( "ejercicio 2 examen" )
{
    // tabla de vértices (m*n)
    // primera fila
    for (unsigned int i=0; i<n; i++)
    {
        vertices.push_back( {i/(n-1.0), 0, 0} );
    }

    for (unsigned int j=1; j<m; j++)
    {
        for (unsigned int i=0; i<n; i++)
        {
            vertices.push_back( { vertices[j-1].x*((1.0*(3-i))/3.0), 0, (j*1.4)/(m-1.0)} );
        }
    }           

    // tabla de triángulos
    for (unsigned int j=0; j<(m-1); j++)
    {
        for (unsigned int i=0; i<(n-1); i++)
        {
            triangulos.push_back( {  i+j*n,   n+i+j*n, i+1+j*n} );
            triangulos.push_back( {n+i+j*n, n+i+1+j*n, i+1+j*n} );
        }
    }   
}

// ****************************************************************************
// Clase 'P3Cuadrado'

P3Cuadrado::P3Cuadrado()
:  MallaInd( "cuadrado" )
{
   vertices = { { -1.0,  0.0, -1.0 }, { -1.0, 0.0, 1.0 }, { 1.0, 0.0, -1.0 }, { 1.0, 0.0, 1.0 } } ;
   triangulos = {  {0,1,3}, {0,3,2} } ;
}

P3Caja::P3Caja()
{
    // variables
    const float angulo1 = -M_PI/2.0;
    const float angulo2 = 0.0;
    const unsigned n_verts = 30;
    const unsigned n_perfil = 40;

    // instancia cara lateral
    NodoGrafoEscena *cara_lat = new NodoGrafoEscena;
    cara_lat-> agregar( glm::translate( glm::vec3( 0.0, 0.0, 1.0 ) ) );
    cara_lat-> agregar( glm::rotate( angulo1, glm::vec3( 1.0, 0.0, 0.0 ) ) );
    cara_lat-> agregar( glm::translate( glm::vec3( 0.0, 0.0, 0.5 ) ) );
    cara_lat-> agregar( glm::scale( glm::vec3( 1.0, 1.0, 0.5 ) ) );
    cara_lat-> agregar( new P3Cuadrado() );

    // instancia hoja superior
    NodoGrafoEscena *hoja_sup = new NodoGrafoEscena;
    hoja_sup-> agregar( glm::translate( glm::vec3( -1.0, 1.0, 0.0 ) ) );
    unsigned ind1 = hoja_sup-> agregar( glm::rotate( angulo2, glm::vec3( 0.0, 0.0, 1.0 ) ) );
    hoja_sup-> agregar( glm::translate( glm::vec3( 0.5, 0.0, 0.0 ) ) );
    hoja_sup-> agregar( glm::scale( glm::vec3( 0.5, 1.0, 1.0 ) ) );
    hoja_sup-> agregar( new P3Cuadrado() );

    // instancia tapadera
    NodoGrafoEscena *tapadera = new NodoGrafoEscena;
    tapadera-> agregar( hoja_sup );
    tapadera-> agregar( glm::scale( glm::vec3( -1.0, 1.0, 1.0 ) ) );
    tapadera-> agregar( hoja_sup );

    // instancia esfera
    NodoGrafoEscena *esfera_esc = new NodoGrafoEscena;
    unsigned ind2 = esfera_esc-> agregar( glm::translate( glm::vec3( 0.0, 0.5, 0.0 ) ) );
    esfera_esc-> agregar( glm::scale( glm::vec3( 0.4, 0.4, 0.4 ) ) );
    esfera_esc-> agregar( new Esfera(n_verts, n_perfil) );

    agregar( esfera_esc );
    agregar( tapadera );
    agregar( new P3Cuadrado() );   // base
    agregar( cara_lat );
    agregar( glm::scale( glm::vec3( 1.0, 1.0, -1.0 ) ) );
    agregar( cara_lat );
    agregar( glm::rotate( angulo1, glm::vec3( 0.0, 1.0, 0.0 ) ) );
    agregar( cara_lat );
    agregar( glm::scale( glm::vec3( 1.0, 1.0, -1.0 ) ) );
    agregar( cara_lat );


    // puntero a la matriz de rotación
    pm_rot_hojas  = hoja_sup->leerPtrMatriz( ind1 );
    pm_tra_esfera = esfera_esc->leerPtrMatriz( ind2 );
}

unsigned P3Caja::leerNumParametros() const 
{
    return 2;
}

void P3Caja::actualizarEstadoParametro( const unsigned iParam, const float t_sec )
{
    if (iParam < leerNumParametros() )
    {
        float vmin_hojas = 0.0;
        float vmax_hojas = M_PI/2.0;
        float v_hojas = (vmin_hojas + vmax_hojas)/2.0 + ((vmax_hojas - vmin_hojas)/2.0)*sin(2*M_PI*t_sec);    // 1 vuelta por segundo
        *pm_rot_hojas = glm::rotate( v_hojas, glm::vec3( 0.0, 0.0, 1.0 ) );

        float vmin_esfera = 1.0;
        float vmax_esfera = 3.5;
        float v_esfera = (vmin_esfera + vmax_esfera)/2.0 + ((vmax_esfera - vmin_esfera)/2.0)*sin(2*M_PI*t_sec);    // 1 vuelta por segundo
        *pm_tra_esfera = glm::translate( glm::vec3( 0.0, 0.5*v_esfera, 0.0 ) );
    }    
}