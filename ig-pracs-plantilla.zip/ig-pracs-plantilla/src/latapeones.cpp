// Nombre: ____, Apellidos: ____, Titulación: ____
// email: ____, DNI: ____

#include "latapeones.h"
#include "aplicacion-ig.h"

// PRÁCTICA 4
//
LataPeones::LataPeones()
{
    // variables
    int nperfiles = 30;

    // materiales
    Material *mat_lata_tapas = new Material( 0.0, 1.0, 1.0, 10.0 );
    Material *mat_lata_cocacola = new Material( new Textura( "lata-coke.jpg" ), 0.6, 0.3, 1.0, 40.0 );
    Material *mat_peon_blanco = new Material( 0.2, 1.0, 0.0, 0.5 );
    Material *mat_peon_negro = new Material( 0.0, 0.1, 1.0, 10.0 );
    Material *mat_peon_madera = new Material( new TexturaXY( "text-madera.jpg" ), 0.1, 1.0, 1.0, 40.0 );

    // lata cuerpo
    NodoGrafoEscena *lata_cuerpo = new NodoGrafoEscena();
    lata_cuerpo-> agregar( mat_lata_cocacola );
    lata_cuerpo-> agregar( new MallaRevolPLY( "lata-pcue.ply", nperfiles ) );    

    // lata
    NodoGrafoEscena *lata = new NodoGrafoEscena();
    lata-> agregar( lata_cuerpo );
    lata-> agregar( mat_lata_tapas );
    lata-> agregar( new MallaRevolPLY( "lata-psup.ply", nperfiles ) );
    lata-> agregar( new MallaRevolPLY( "lata-pinf.ply", nperfiles ) );

    // peon genérico
    NodoGrafoEscena *peon = new NodoGrafoEscena();
    peon-> agregar( glm::translate( glm::vec3( 0.0, 0.0, 0.85 ) ) );
    peon-> agregar( glm::scale( glm::vec3( 0.15, 0.15, 0.15 ) ) );
    peon-> agregar( glm::translate( glm::vec3( 0.0, 1.4, 0.0 ) ) );
    peon-> agregar( new MallaRevolPLY( "peon.ply", nperfiles ) );

    // peon negro
    NodoGrafoEscena *peon_negro = new NodoGrafoEscena();
    peon_negro-> agregar( mat_peon_negro );
    peon_negro-> agregar( peon );

    // peon blanco
    NodoGrafoEscena *peon_blanco = new NodoGrafoEscena();
    peon_blanco-> ponerColor( glm::vec3( 1.0, 1.0, 1.0 ) );
    peon_blanco-> agregar( mat_peon_blanco );
    peon_blanco-> agregar( peon );

    // peon madera
    NodoGrafoEscena *peon_madera = new NodoGrafoEscena();
    peon_madera-> agregar( mat_peon_madera );
    peon_madera-> agregar( peon );

    agregar( lata );
    agregar( peon_madera );
    agregar( glm::translate( glm::vec3( 0.425, 0.0, 0.0 ) ) );
    agregar( peon_blanco );
    agregar( glm::translate( glm::vec3( 0.425, 0.0, 0.0 ) ) );
    agregar( peon_negro );
}

// PRÁCTICA 5
//
Lata::Lata( std::string textura )
{
    // variables
    int nperfiles = 30;

    // materiales
    Material *mat_lata_tapas = new Material( 0.0, 1.0, 1.0, 10.0 );
    Material *mat_lata_cuerpo = new Material( new Textura( textura ), 0.6, 0.3, 1.0, 40.0 );

    agregar( mat_lata_tapas );
    agregar( new MallaRevolPLY( "lata-psup.ply", nperfiles ) );
    agregar( new MallaRevolPLY( "lata-pinf.ply", nperfiles ) );
    agregar( mat_lata_cuerpo );
    agregar( new MallaRevolPLY( "lata-pcue.ply", nperfiles ) );   
}

VariasLatasPeones::VariasLatasPeones()
{
    // variables
    int nperfiles = 30;
    int id_lata_coke   = 1;
    int id_lata_pepsi  = 2;
    int id_lata_ugr    = 3;
    int id_peon_madera = 4;
    int id_peon_blanco = 5;
    int id_peon_negro  = 6;    

    // materiales peones
    Material *mat_peon_madera = new Material( new TexturaXY( "text-madera.jpg" ), 0.1, 1.0, 1.0, 40.0 );
    Material *mat_peon_blanco = new Material( 0.2, 1.0, 0.0, 0.5 );
    Material *mat_peon_negro = new Material( 0.0, 0.1, 1.0, 10.0 );    

    // lata ugr
    NodoGrafoEscena *lata_ugr = new NodoGrafoEscena();
    lata_ugr-> ponerIdentificador( id_lata_ugr );
    lata_ugr-> ponerNombre( "Lata de la UGR" );
    lata_ugr-> agregar( glm::translate( glm::vec3(0.88*2, 0.0, 0.0) ) );
    lata_ugr-> agregar( new Lata( "window-icon.jpg" ) );    

    // lata pepsi
    NodoGrafoEscena *lata_pepsi = new NodoGrafoEscena();
    lata_pepsi-> ponerIdentificador( id_lata_pepsi );
    lata_pepsi-> ponerNombre( "Lata de Pepsi" );
    lata_pepsi-> agregar( glm::translate( glm::vec3(0.88, 0.0, 0.0) ) );
    lata_pepsi-> agregar( new Lata( "lata-pepsi.jpg" ) ); 

    // lata cocacola
    NodoGrafoEscena *lata_cocacola = new NodoGrafoEscena();
    lata_cocacola-> ponerIdentificador( id_lata_coke );
    lata_cocacola-> ponerNombre( "Lata de Coca-Cola" );
    lata_cocacola-> agregar( new Lata( "lata-coke.jpg" ) );

    // peon negro
    PeonMovil *peon_negro = new PeonMovil(nperfiles);
    peon_negro-> ponerIdentificador( id_peon_negro);
    peon_negro-> ponerNombre( "Peón negro" );

    // peon blanco
    PeonMovil *peon_blanco = new PeonMovil(nperfiles);
    peon_blanco-> ponerIdentificador( id_peon_blanco );
    peon_blanco-> ponerNombre( "Peón blanco" );

    // peon madera
    PeonMovil *peon_madera = new PeonMovil(nperfiles);
    peon_madera-> ponerIdentificador( id_peon_madera );
    peon_madera-> ponerNombre( "Peón de madera" );

    agregar( lata_ugr );
    agregar( lata_pepsi );
    agregar( lata_cocacola );
    agregar( mat_peon_madera );
    agregar( peon_madera );
    agregar( glm::translate( glm::vec3( 0.425, 0.0, 0.0 ) ) );
    agregar( mat_peon_blanco );
    agregar( peon_blanco );
    agregar( glm::translate( glm::vec3( 0.425, 0.0, 0.0 ) ) );
    agregar( mat_peon_negro );
    agregar( peon_negro );
}

PeonMovil::PeonMovil( int nperfiles )
{
    unsigned ind = agregar( glm::translate( glm::vec3(0.0, 0.0, 0.0) ) );

    agregar( glm::translate( glm::vec3( 0.0, 0.0, 0.85 ) ) );
    agregar( glm::scale( glm::vec3( 0.15, 0.15, 0.15 ) ) );
    agregar( glm::translate( glm::vec3( 0.0, 1.4, 0.0 ) ) );
    agregar( new MallaRevolPLY( "peon.ply", nperfiles ) );

    // puntero a la matriz de traslación del peón
    mat_traslacion = leerPtrMatriz( ind );
}

bool PeonMovil::cuandoClick( const glm::vec3 & centro_wc )
{
    bool revisualizar = true;
    contador_clicks = contador_clicks + 1;
    *mat_traslacion = glm::translate( glm::vec3( 0.0, 0.0, contador_clicks*0.5 ) );
    
    return revisualizar;
}
