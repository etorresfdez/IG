// Nombre: ____, Apellidos: ____, Titulación: ____
// email: ____, DNI: ____

#include "ig-aux.h"  
#include "grafo-escena.h"
#include "aplicacion-ig.h"


//**************************************************************************
// Clase LataPeones - Práctica 4

class LataPeones : public NodoGrafoEscena
{
    public:
        LataPeones();
};


//**************************************************************************
// Clase VariasLatasPeones - Práctica 5

class Lata : public NodoGrafoEscena
{
    public:
        Lata( std::string textura );
};

class VariasLatasPeones : public NodoGrafoEscena
{
    public:
        VariasLatasPeones();
};

class PeonMovil : public NodoGrafoEscena
{
    public:
        PeonMovil( int nperfiles );
        virtual bool cuandoClick( const glm::vec3 & centro_wc) ;

    protected:
        glm::mat4 *mat_traslacion = nullptr;
        unsigned contador_clicks = 0;
};
