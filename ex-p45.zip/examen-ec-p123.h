// Nombre: Elena, Apellidos: Torres Fernández, Titulación: GIM
// email: eletofer26@correo.ugr.es, DNI: 77169308F

#ifndef EXAMEN_EC_P123_HPP
#define EXAMEN_EC_P123_HPP
#include "malla-ind.h"
#include "grafo-escena.h"

// ---------------------------------------------------------------------
// Ejercicio 1 EXAMEN

class P1MallaCubo : public MallaInd
{
   public:
      P1MallaCubo();
};

// ---------------------------------------------------------------------
// Ejercicio 2 EXAMEN

class P2Rejilla : public MallaInd
{
   public:
      P2Rejilla(unsigned int m, unsigned int n);
};

// ---------------------------------------------------------------------
// Ejercicio 3 EXAMEN

class P3Cuadrado : public MallaInd
{
    public:
        P3Cuadrado();
};

class P3Caja : public NodoGrafoEscena
{
    protected:
        glm::mat4 *pm_rot_hojas  = nullptr; // ind1
        glm::mat4 *pm_tra_esfera = nullptr; // ind2

    public:
        P3Caja();
        virtual unsigned leerNumParametros() const; 
        virtual void actualizarEstadoParametro( const unsigned iParam, const float t_sec );
};


#endif