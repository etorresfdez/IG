// Nombre: Elena, Apellidos: Torres Fernández, Titulación: GIM
// email: eletofer26@correo.ugr.es, DNI: 77169308F
// ***********************************************************************
// **
// ** Asignatura: INFORMÁTICA GRÁFICA
// ** 
// ** Diseño e implementación de un grado de escena parametrizado original
// **
// ***********************************************************************


#include "grafo-escena.h"


// *********************************************************************
// EJEMPLO DIAPOSITIVAS
// Fachada de una casa compuesta de ventanas con marcos y una puerta

class Ventana : public NodoGrafoEscena
{
   public:
   Ventana();  // Constructor
};

class Marcos : public NodoGrafoEscena
{
   public:
   Marcos();   // Constructor
};

class MarcoIzq : public NodoGrafoEscena
{
   public:
   MarcoIzq(); // Constructor
};

class Puerta : public NodoGrafoEscena
{
   public:
   Puerta();
};

class HojaDer : public NodoGrafoEscena
{
   public:
   HojaDer();
};

class Pomo : public NodoGrafoEscena
{
   public:
   Pomo();
};

class Fachada : public NodoGrafoEscena
{
   public:
   Fachada();
};

class FachadaP : public NodoGrafoEscena
{
   protected:
      glm::mat4 *pm_rot_alpha = nullptr;
      glm::mat4 *pm_escy_h    = nullptr;

   public:
      FachadaP( float h, float alpha );
      void fijarH( const float h_nuevo );
      void fijarAlpha( const float alpha_nuevo );
};


// *********************************************************************
// EJERCICIO ORIGINAL - CANASTA DE BALONCESTO

class Postes : public NodoGrafoEscena
{
   public:
   Postes();
};

class PosteVer : public NodoGrafoEscena
{
   public:
   PosteVer();
};

class PosteHor : public NodoGrafoEscena
{
   public:
   PosteHor();
};

class PosteDia : public NodoGrafoEscena
{
   public:
   PosteDia();
};

class Cuadro : public NodoGrafoEscena
{
   public:
   Cuadro();
};

class Aro : public NodoGrafoEscena
{
   public:
   Aro();
};

class Canasta : public NodoGrafoEscena
{
   public:
   Canasta();
};

class CanastaP : public NodoGrafoEscena
{
   protected:
      glm::mat4 *pm_alt_poste = nullptr;  // ind1
      glm::mat4 *pm_alt_resto = nullptr;  // ind2
      glm::mat4 *pm_esc_aro   = nullptr;  // ind3
      glm::mat4 *pm_tra_aro   = nullptr;  // ind4
      glm::mat4 *pm_alp_rot   = nullptr;  // ind5

   public:
      CanastaP( float paltura, float pradio, float palpha );
      virtual unsigned leerNumParametros() const; 
      virtual void actualizarEstadoParametro( const unsigned iParam, const float t_sec );
};