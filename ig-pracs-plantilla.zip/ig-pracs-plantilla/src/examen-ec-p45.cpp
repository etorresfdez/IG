// Nombre: ____, Apellidos: ____, Titulación: ____
// email: ____, DNI: ____

#include "examen-ec-p45.h"

MallaP4::MallaP4()
{
    vertices =
        {   { +1.0, +1.0, +1.0 }, // X +
            { +1.0, -1.0, +1.0 },
            { +1.0, -1.0, -1.0 },
            { +1.0, +1.0, -1.0 },

            { -1.0, +1.0, +1.0 }, // Y +
            { +1.0, +1.0, +1.0 },
            { +1.0, +1.0, -1.0 },
            { -1.0, +1.0, -1.0 },

            { -1.0, -1.0, +1.0 }, // X -
            { -1.0, +1.0, +1.0 },
            { -1.0, +1.0, -1.0 },
            { -1.0, -1.0, -1.0 },

            { +1.0, -1.0, +1.0 }, // Y -
            { -1.0, -1.0, +1.0 },
            { -1.0, -1.0, -1.0 },
            { +1.0, -1.0, -1.0 },

            { +1.0, +1.0, +1.0 }, // Z +
            { -1.0, +1.0, +1.0 },
            { -1.0, -1.0, +1.0 },
            { +1.0, -1.0, +1.0 },

            { +1.0, +1.0, -1.0 }, // Z -
            { +1.0, -1.0, -1.0 },
            { -1.0, -1.0, -1.0 },
            { -1.0, +1.0, -1.0 },

            { +1.0, +1.0, +1.0 }, // pirámide x+
            {  0.0,  2.0,  0.0 },

            { +1.0, +1.0, -1.0 }, // pirámide z-
            {  0.0,  2.0,  0.0 },

            { -1.0, +1.0, -1.0 }, // pirámide x-
            {  0.0,  2.0,  0.0 },

            { -1.0, +1.0, +1.0 }, // pirámide z+
            {  0.0,  2.0,  0.0 }      
        } ;

    triangulos =   
        {   {  0,  1,  2 }, {  0,  2,  3 }, // X +
            {  4,  5,  6 }, {  4,  6,  7 }, // Y +
            {  8,  9, 10 }, {  8, 10, 11 }, // X -
            { 12, 13, 14 }, { 12, 14, 15 }, // Y -
            { 16, 17, 18 }, { 16, 18, 19 }, // Z +
            { 20, 21, 22 }, { 20, 22, 23 },  // Z -

            { 31, 0, 3 }, { 31, 3, 10 }, { 31, 10, 9 }, { 31, 9, 0 } // triángulos cúspide
        } ;

    cc_tt_ver = 
        {
            // faltan
        } ;

    calcularNormales();
}


NodoP4::NodoP4()
{
    Material *material_casa = new Material( new Textura( "ventanas-tejado-2048x1024.jpg" ), 0.6, 0.8, 0.1, 15.0 );

    agregar( material_casa );
    agregar( new MallaP4() );
}

NodoUrbaP5::NodoUrbaP5( int n )
{
    float angulo = 0.0;
    unsigned ind = agregar( glm::rotate( angulo, glm::vec3( 0.0, 1.0, 0.0 ) ) );

    agregar( new NodoP4() );

    for (int i=0; i<n-1; i++)
    {
        NodoP4 * una_casa = new NodoP4();
        una_casa->ponerIdentificador(i+1);
        una_casa->ponerNombre( "Una Casa" );

        agregar( glm::translate( glm::vec3( 2.0, 0.0, 0.0 ) ) );
        agregar( una_casa );
    }

    // puntero a la matriz de traslación del peón
    mat_rotacion = leerPtrMatriz( ind );
}

bool NodoUrbaP5::cuandoClick( const glm::vec3 & centro_wc )
{
    bool revisualizar = true;
    float angulo = 30.0*180/M_PI;

    *mat_rotacion = glm::rotate( angulo, glm::vec3( 0.0, 1.0, 0.0 ) );
    std::cout << "Casa " << leerIdentificador() << std::endl;
    
    return revisualizar;
}
